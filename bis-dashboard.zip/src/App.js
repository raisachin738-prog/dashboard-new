import React from 'react';
import BISDashboard from './Dashboard';

function App() {
  return <BISDashboard />;
}

export default App;
